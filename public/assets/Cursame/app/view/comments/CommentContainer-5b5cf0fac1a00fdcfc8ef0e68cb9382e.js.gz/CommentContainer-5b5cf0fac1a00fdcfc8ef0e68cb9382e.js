/**
 * @class Cursame.view.comments.CommentContainer
 * @extends Ext.cont
 * Description
 */
Ext.define("Cursame.view.comments.CommentContainer",{extend:"Ext.Container",xtype:"commentcontainer",config:{tpl:Ext.create("Cursame.view.comments.CommentTpl",!0)}});