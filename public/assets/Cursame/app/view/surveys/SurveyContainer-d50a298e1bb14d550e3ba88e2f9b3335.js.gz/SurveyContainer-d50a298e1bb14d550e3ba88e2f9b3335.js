/**
 * @class Cursame.view.courses.CourseContainer
 * @extends Ext.Container
 * Este es el contenedor que muestran el curso y su layout
 */
Ext.define("Cursame.view.surveys.SurveyContainer",{extend:"Ext.Container",xtype:"surveycontainer",config:{tpl:Ext.create("Cursame.view.surveys.SurveyTpl",!0)}});