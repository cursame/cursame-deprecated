/**
 * @class Cursame.store.Surveys
 * @extends Core.data.Store
 * This is the Surveys store of Cursame
 */
Ext.define("Cursame.store.Surveys",{extend:"Core.data.Store",requires:["Cursame.model.Survey"],config:{model:"Cursame.model.Survey"}});