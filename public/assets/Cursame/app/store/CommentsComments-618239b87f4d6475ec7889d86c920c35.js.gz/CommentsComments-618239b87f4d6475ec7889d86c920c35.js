/**
 * @class Cursame.store.CommentsComments
 * @extends Ext.data.Store
 * This is the comments of comments store of Cursame
 */
Ext.define("Cursame.store.CommentsComments",{extend:"Cursame.store.Comments"});