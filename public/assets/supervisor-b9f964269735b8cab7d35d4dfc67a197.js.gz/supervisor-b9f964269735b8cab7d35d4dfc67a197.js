/*
 Javascripts for Supervisor layout.
*/
$(document).ready(function(){$(".tabs").tabs(),$(".change_role_button").click(function(){$(this).parent().next().show(400),$(this).parent().hide(400)})});